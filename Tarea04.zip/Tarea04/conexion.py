import pyodbc

class Conexion:
    def __init__(self):
        self.driver = '{ODBC Driver 17 for SQL Server}'
        self.server = 'localhost'
        self.database = 'servicioElectrico'
        self.username = 'Helder3'
        self.password = 'Helder2004.'

    def conectar(self):
        try:
            connection_string = f'DRIVER={self.driver};SERVER={self.server};DATABASE={self.database};UID={self.username};PWD={self.password}'
            conn = pyodbc.connect(connection_string)
            return conn
        except pyodbc.Error as e:
            print(f'Error de conexión: {e}')
            return None
        
    def desconectar(self, conn):
        try:
            conn.close()
            print('Conexión cerrada.')
        except pyodbc.Error as e:
            print(f'Error al cerrar la conexión: {e}')

    def agregarCliente(self, nombre, direccion, telefono, email):
        conn = self.conectar()
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute("INSERT INTO cliente (nombre, direccion, telefono, email) VALUES (?, ?, ?, ?)", (nombre, direccion, telefono, email))
                conn.commit()
                print('Cliente agregado correctamente.')
            except pyodbc.Error as e:
                print(f'Error al agregar cliente: {e}')
            finally:
                cursor.close()
                self.desconectar(conn)
    
    def editarCliente(self, clienteID, nombre, direccion, telefono, email):
        conn = self.conectar()
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute("UPDATE cliente SET nombre=?, direccion=?, telefono=?, email=? WHERE clienteID=?", (nombre, direccion, telefono, email, clienteID))
                conn.commit()
                print('Cliente editado correctamente.')
            except pyodbc.Error as e:
                print(f'Error al editar cliente: {e}')
            finally:
                cursor.close()
                self.desconectar(conn)
    
    def eliminarCliente(self, clienteID):
        conn = self.conectar()
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute("DELETE FROM cliente WHERE clienteID=?", (clienteID,))
                conn.commit()
                print("Cliene eliminado correctamente.")
            except pyodbc.Error as e:
                print(f'Error al eliminar cliente: {e}')
            finally:
                cursor.close()
                self.desconectar(conn)

    def verClientes(self):
        conn = self.conectar()
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute("SELECT * FROM cliente")
                rows = cursor.fetchall()
                for row in rows:
                    print(row)
            except pyodbc.Error as e:
                print(f'Error al ver clientes: {e}')
            finally:
                cursor.close()
                self.desconectar(conn)

    def agregarConsumo(self, clienteID, mes, año, consumoKwh, precio = 0.25):
        conn = self.conectar()
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute("INSERT INTO consumo (clienteID, mes, año, consumoKwh, precio) VALUES (?, ?, ?, ?, ?)", (clienteID, mes, año, consumoKwh, precio))
                conn.commit()
                print('Consumo agregado correctamente.')
            except pyodbc.Error as e:
                print(f'Error al agregar consumo: {e}')
            finally:
                cursor.close()
                self.desconectar(conn)
    
    def historialConsumo(self, clienteID):
        conn = self.conectar()
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute("""
                    SELECT * FROM consumo
                    WHERE clienteID = ?
                    ORDER BY año DESC, mes DESC
                """, (clienteID,))
                return cursor.fetchall()
            except pyodbc.Error as e:
                print(f"Error al obtener historial de consumo: {e}")
                return []
            finally:
                cursor.close()
                self.desconectar(conn)

    def alertasConsumoAlto(self, umbral=500):
        conn = self.conectar()
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute("SELECT * FROM consumo WHERE consumoKWh > ?", (umbral,))
                return cursor.fetchall()
            except pyodbc.Error as e:
                print(f"Error al obtener alertas de consumo alto: {e}")
                return []
            finally:
                cursor.close()
                self.desconectar(conn)

    def calcularFactura(self, clienteID, mes, año):
        conn = self.conectar()
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute("""
                    SELECT consumoKWh * precio AS total
                    FROM consumo
                    WHERE clienteID = ? AND mes = ? AND año = ?
                """, (clienteID, mes, año))
                resultado = cursor.fetchone()
                return resultado[0] if resultado else 0
            except pyodbc.Error as e:
                print(f"Error al calcular factura: {e}")
                return 0
            finally:
                cursor.close()
                self.desconectar(conn)

    def generarFactura(self, clienteID, montoTotal, estado=1):
        conn = self.conectar()
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute("""
                    INSERT INTO factura (clienteID, montoTotal, estado)
                    VALUES (?, ?, ?)
                """, (clienteID, montoTotal, estado))
                conn.commit()
                print("Factura generada correctamente.")
            except pyodbc.Error as e:
                print(f"Error al generar factura: {e}")
            finally:
                cursor.close()
                self.desconectar(conn)

    def historialFacturas(self, clienteID):
        conn = self.conectar()
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute("""
                    SELECT * FROM factura
                    WHERE clienteID = ?
                    ORDER BY fechaEmision DESC
                """, (clienteID,))
                return cursor.fetchall()
            except pyodbc.Error as e:
                print(f"Error al obtener historial de facturas: {e}")
                return []
            finally:
                cursor.close()
                self.desconectar(conn)
