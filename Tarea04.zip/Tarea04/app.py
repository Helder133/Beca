from flask import Flask, render_template, request, redirect, url_for
from conexion import Conexion

app = Flask(__name__)
conexion = Conexion()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/agregarCliente', methods=['GET','POST'])
def agregarCliente():
    if request.method == 'POST':
        nombre = request.form['nombre']
        direccion = request.form['direccion']
        telefono = request.form['telefono']
        email = request.form['email']
        conexion.agregarCliente(nombre, direccion, telefono, email)
        return redirect(url_for('listarClientes'))
    return render_template('agregarCliente.html')

@app.route('/listarClientes')
def listarClientes():
    clientes = conexion.verClientes()
    return render_template('listarClientes.html', clientes=clientes)

@app.route('/editarCliente/<int:clienteID>', methods=['GET', 'POST'])
def editarCliente(clienteID):
    if request.method == 'POST':
        nombre = request.form['nombre']
        direccion = request.form['direccion']
        telefono = request.form['telefono']
        email = request.form['email']
        conexion.editarCliente(clienteID, nombre, direccion, telefono, email)
        return redirect(url_for('listarClientes'))
    cliente = conexion.verCliente(clienteID)
    return render_template('editarCliente.html', cliente=cliente)

@app.route('/eliminarCliente/<int:clienteID>', methods=['POST'])
def eliminarCliente(clienteID):
    conexion.eliminarCliente(clienteID)
    return redirect(url_for('listarClientes'))

@app.route('/agregarConsumo', methods=['GET', 'POST'])
def agregarConsumo():
    if request.method == 'POST':
        clienteID = request.form['clienteID']
        mes = request.form['mes']
        año = request.form['año']
        consumoKwh = request.form['consumoKwh']
        conexion.agregarConsumo(clienteID, mes, año, consumoKwh)
        return redirect(url_for('listarClientes'))
    clientes = conexion.verClientes()
    return render_template('agregarConsumo.html', clientes=clientes)

@app.route('/verHistorialConsumo/<int:clienteID>')
def verHistorialConsumo(clienteID):
    historial = conexion.historialConsumo(clienteID)
    return render_template('historialConsumo.html', historial=historial, clienteID=clienteID)

@app.route('/generarFactura', methods=['POST'])
def generarFactura():
    clienteID = request.form['clienteID']
    mes = request.form['mes']
    año = request.form['año']
    montoTotal = conexion.calcularFactura(clienteID, mes, año)
    conexion.generarFactura(clienteID, montoTotal)
    return redirect(url_for('listarClientes'))

@app.route('/verFacturas/<int:clienteID>')
def verFacturas(clienteID):
    facturas = conexion.historialFacturas(clienteID)
    return render_template('historialFacturas.html', facturas=facturas, clienteID=clienteID)

if __name__ == '__main__':
    app.run(debug=True)