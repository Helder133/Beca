const express = require('express');
const app = express();
const ordenRoutes = require('./routes/ordenRoutes');

app.use(express.json());
app.use('/orden', ordenRoutes);

app.listen(3000, () => {
    console.log('Servidor escuchando en http://localhost:3000');
});