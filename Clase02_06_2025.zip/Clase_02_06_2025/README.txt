# Proyecto: Trama WebService Node.js

Este proyecto permite recibir una trama vía WebService, descomponerla, actualizar el estado de una orden en la base de datos y retornar una nueva trama de respuesta.

## Estructura de la trama
- Entrada: "12345|EnProceso"
- Salida: "12345|EnProceso|OK"

## Requisitos
- Node.js
- SQL Server con tabla Ordenes(id INT, estado VARCHAR)
- Instalar dependencias:
  npm install express mssql

## Ejecutar
1. Ejecutar SQL para crear tabla:
   CREATE TABLE Ordenes (id INT PRIMARY KEY, estado VARCHAR(50));
   INSERT INTO Ordenes VALUES (12345, 'Pendiente');

2. Configurar credenciales en `models/db.js`.

3. Ejecutar:
   node app.js

4. Probar con Postman:
   POST http://localhost:3000/orden/procesar
   Body:
   {
     "trama": "12345|EnProceso"
   }