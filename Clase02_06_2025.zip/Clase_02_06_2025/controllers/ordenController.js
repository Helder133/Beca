const { actualizarEstadoOrden } = require('../models/ordenModel');

async function procesarTrama(req, res) {
    try {
        const { trama } = req.body;
        const [idOrden, nuevoEstado] = trama.split('|');
        const ordenActualizada = await actualizarEstadoOrden(idOrden, nuevoEstado);
        const respuestaTrama = `${ordenActualizada.id}|${ordenActualizada.estado}|OK`;
        res.json({ respuesta: respuestaTrama });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error al procesar la trama" });
    }
}

module.exports = { procesarTrama };