//actualizarEstadoORden: Función importada desde el modelo ordenModel.js
//se encarga de actualizar una orden en la base de datos.
const { actualizarEstadoOrden } = require('../models/ordenModel');
//notificarCliente: Función importada de nodificador.js, usada para enviar
//un mensaje a loclientes websocket conectados.
const { notificarCliente } = require('../utils/notificador');

//Esta función es asincrónica y maneja uan petición HTTP. Probablemente
//esté enalazada a una ruta tipo POST/procesar.
async function procesarTrama(req, res) {
    try {
        //Se extrae del cuerpo de la solicitud un campo llamado trama, por ejemplo
        //{"trama":"1234|procesada"}
        const { trama } = req.body;
        //La trama es una cadena con datos separados por |.
        //Se divide para obtener idOrden:1234, nuevoEstado:procesada
        const [idOrden, nuevoEstado] = trama.split('|');
        //Se llama a la función del modelo para actualizar la orden en la base de datos con el nuevo estado
        const ordenActualizada = await actualizarEstadoOrden(idOrden, nuevoEstado);
        //El resultado devuelto(ordenActualizada) incluye los campos id y estado
        //Se construye una nueva trama de respeusta con el formato id|estado|OK
        const respuestaTrama = `${ordenActualizada.id}|${ordenActualizada.estado}|OK`;
        notificarCliente(`Solicitud: ${trama} -> Respuesta: ${respuestaTrama}`);
        //Se envíe la respuesta por Websocket a los clientes conectadso, como una notificación
        //de lo que se procesó.
        res.json({ respuesta: respuestaTrama });
        //Se responde a quien hizo la petición HTTP con la trama de respuesta, en
        //formato JSON.

        //Si ocurre un error, se muestra en consola y se repsponde al cliente
        //HTTP con error 500
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error al procesar la trama" });
    }
}

module.exports = { procesarTrama };