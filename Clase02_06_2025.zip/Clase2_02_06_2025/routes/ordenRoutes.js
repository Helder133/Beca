const express = require('express');
const router = express.Router();
const { procesarTrama } = require('../controllers/ordenController');

router.post('/procesar', procesarTrama);

module.exports = router;