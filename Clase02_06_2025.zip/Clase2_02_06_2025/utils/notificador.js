let clientes = [];

function agregarCliente(ws) {
    clientes.push(ws);
}

function eliminarCliente(ws) {
    clientes = clientes.filter(c => c !== ws);
}

function notificarCliente(mensaje) {
    clientes.forEach(c => {
        if (c.readyState === 1) {
            c.send(mensaje);
        }
    });
}

module.exports = {
    agregarCliente,
    eliminarCliente,
    notificarCliente
};