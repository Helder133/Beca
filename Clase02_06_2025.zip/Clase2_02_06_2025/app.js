const express = require('express');
const path = require('path');
const http = require('http');
//Biblioteca que maneja websockets
const WebSocket = require('ws');
//Funciones definidas en el módulo local notificador.js apra
//gestionar los clientes conectados por websocket.
const { agregarCliente, eliminarCliente } = require('./utils/notificador');
//Módulo que maneja las rutas HTTP relaconadas con las órdenes.
const ordenRoutes = require('./routes/ordenRoutes');

//Instancia de una aplicación Express
const app = express();
//Crear un servidor http sobre app.
const server = http.createServer(app);
//Crear un servidor websocket que se monta sobre el servidor HTTP,
//permitiendo compartir el mismo puerto.
const wss = new WebSocket.Server({ server });

//Manejo de las conexiones websocket
//Cuando un cliente se conecta se ejecuta la función
//wss.on('close',...): Elimina al cliente si se desconecta
//agregarCliente(ws):Registra la nueva conexión.
wss.on('connection', function connection(ws) {
    agregarCliente(ws);
    ws.on('close', () => eliminarCliente(ws));
});

//Permite que Express interprete json en el cuerpo de las solicitudes
app.use(express.json());
//express.static(...): Sirve archivos estáticos desde la carpeta public (html, css. js)
app.use(express.static(path.join(__dirname, 'public')));
//Asocia las rutas que inician con /orden a las definidas en el módulo
//ordenRoutes.
app.use('/orden', ordenRoutes);

//Inicia el servidor HTTP+Websocket en el puerto 3000
server.listen(3000, () => {
    console.log('Servidor HTTP/WebSocket corriendo en http://localhost:3000');
});