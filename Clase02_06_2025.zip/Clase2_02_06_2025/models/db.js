const sql = require('mssql');

const config = {
    user: 'marsolca',
    password: 'marsolca',
    server: 'localhost',
    database: 'MiBaseDatos',
    options: {
        trustServerCertificate: true
    }
};

sql.connect(config)
    .then(() => console.log('Conectado a la base de datos'))
    .catch(err => console.error('Error de conexión', err));

module.exports = sql;