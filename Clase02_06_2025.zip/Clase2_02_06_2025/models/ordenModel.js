const sql = require('./db');

async function actualizarEstadoOrden(idOrden, nuevoEstado) {
    const result = await sql.query`
        UPDATE Ordenes SET estado = ${nuevoEstado} WHERE id = ${idOrden};
        SELECT * FROM Ordenes WHERE id = ${idOrden};
    `;
    return result.recordset[0];
}

module.exports = { actualizarEstadoOrden };