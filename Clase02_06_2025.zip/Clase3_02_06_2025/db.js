const sql = require('mssql');

const config = {
    user: 'Helder10',
    password: '123',
    server: 'localhost',
    database: 'BancoDB',
    options: { trustServerCertificate: true }
};

module.exports = {
    sql, config
};