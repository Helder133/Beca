const express = require('express');
const { sql, config } = require('./db');
const WebSocket = require('ws');
const path = require('path');

const app = express();
app.use(express.static(path.join(__dirname, 'public')));

const server = app.listen(3000, () => {
    console.log('Servidor web en http://localhost:3000');
});

const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
    ws.on('message', async (mensaje) => {
        const trama = mensaje.toString().trim();
        const [accion, cuenta, montoStr] = trama.split('|');
        const monto = parseFloat(montoStr || 0);

        try {
            const pool = await sql.connect(config);
            let result, respuesta;

            switch (accion.toUpperCase()) {
                case 'CONSULTA':
                    result = await pool.request()
                        .input('cuenta', sql.VarChar, cuenta)
                        .query('SELECT saldo FROM Cuentas WHERE numeroCuenta = @cuenta');
                    if (result.recordset.length > 0) {
                        respuesta = `Saldo disponible: ₡${result.recordset[0].saldo}`;
                    } else {
                        respuesta = 'ERROR: Cuenta no encontrada';
                    }
                    break;

                case 'DEPOSITO':
                    const deposito = await pool.request()
                        .input('cuenta', sql.VarChar, cuenta)
                        .input('monto', sql.Decimal(12, 2), monto)
                        .query('UPDATE Cuentas SET saldo = saldo + @monto WHERE numeroCuenta = @cuenta');

                    if (deposito.rowsAffected[0] > 0) {
                        await pool.request()
                            .input('cuenta', sql.VarChar, cuenta)
                            .input('monto', sql.Decimal(12, 2), monto)
                            .input('tipo', sql.VarChar, 'DEPOSITO')
                            .query('INSERT INTO Movimientos (numeroCuenta, tipoMovimiento, monto) VALUES (@cuenta, @tipo, @monto)');
                        respuesta = `Depósito exitoso de ₡${monto}`;
                    } else {
                        respuesta = 'ERROR: Cuenta no encontrada';
                    }
                    break;

                case 'RETIRO':
                    const saldoResult = await pool.request()
                        .input('cuenta', sql.VarChar, cuenta)
                        .query('SELECT saldo FROM Cuentas WHERE numeroCuenta = @cuenta');

                    if (saldoResult.recordset.length === 0) {
                        respuesta = 'ERROR: Cuenta no encontrada';
                    } else if (saldoResult.recordset[0].saldo < monto) {
                        respuesta = 'ERROR: Fondos insuficientes';
                    } else {
                        await pool.request()
                            .input('cuenta', sql.VarChar, cuenta)
                            .input('monto', sql.Decimal(12, 2), monto)
                            .query('UPDATE Cuentas SET saldo = saldo - @monto WHERE numeroCuenta = @cuenta');

                        await pool.request()
                            .input('cuenta', sql.VarChar, cuenta)
                            .input('monto', sql.Decimal(12, 2), monto)
                            .input('tipo', sql.VarChar, 'RETIRO')
                            .query('INSERT INTO Movimientos (numeroCuenta, tipoMovimiento, monto) VALUES (@cuenta, @tipo, @monto)');

                        respuesta = `Retiro exitoso de ₡${monto}`;
                    }
                    break;

                default:
                    respuesta = 'ERROR: Acción no válida';
            }

            ws.send(respuesta);
        } catch (error) {
            console.error('Error:', error);
            ws.send('ERROR: Problema en el servidor');
        }
    });
});